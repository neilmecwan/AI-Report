import { MultipartFile } from '@fastify/multipart';
import sharp from 'sharp';
import path from 'path';
import fs from 'fs/promises';
import { env } from '../config/env';
import { generateId } from '../utils/ids';
import { BadRequestError } from '../utils/errors';

const ALLOWED_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
]);

export async function processUpload(file: MultipartFile) {
  if (!ALLOWED_TYPES.has(file.mimetype)) {
    throw new BadRequestError(`File type ${file.mimetype} not allowed`);
  }

  const id = generateId();
  const filename = `${id}${path.extname(file.filename)}`;
  const filepath = path.join(env.STORAGE_DIR, filename);

  // Create storage directory if it doesn't exist
  await fs.mkdir(env.STORAGE_DIR, { recursive: true });

  // Process images with sharp
  if (file.mimetype.startsWith('image/')) {
    const buffer = await file.toBuffer();
    await sharp(buffer)
      .resize(2000, 2000, { fit: 'inside', withoutEnlargement: true })
      .jpeg({ quality: 80 })
      .toFile(filepath);
  } else {
    // For non-image files, save directly
    const buffer = await file.toBuffer();
    await fs.writeFile(filepath, buffer);
  }

  return {
    id,
    name: file.filename,
    type: file.mimetype,
    size: file.file.bytesRead,
  };
}