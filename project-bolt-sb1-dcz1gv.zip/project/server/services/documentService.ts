import OpenAI from 'openai';
import { env } from '../config/env';
import { DocumentPreferences } from '../types/document';
import { NotFoundError } from '../utils/errors';
import { generateId } from '../utils/ids';

const openai = new OpenAI({
  apiKey: env.OPENAI_API_KEY,
});

// In-memory store for document generation status (replace with Redis/DB in production)
const documentStore = new Map<string, {
  status: 'processing' | 'completed' | 'failed';
  url?: string;
  format: string;
  message?: string;
}>();

export async function generateDocument({ preferences, fileIds }: {
  preferences: DocumentPreferences;
  fileIds: string[];
}) {
  const documentId = generateId();
  
  // Start processing in background
  documentStore.set(documentId, {
    status: 'processing',
    format: preferences.format,
  });

  // Process document asynchronously
  processDocument(documentId, preferences, fileIds).catch(error => {
    documentStore.set(documentId, {
      status: 'failed',
      format: preferences.format,
      message: error.message,
    });
  });

  return {
    documentId,
    status: 'processing',
    format: preferences.format,
  };
}

export async function regenerateDocument(
  documentId: string,
  preferences?: Partial<DocumentPreferences>
) {
  const existingDoc = documentStore.get(documentId);
  if (!existingDoc) {
    throw new NotFoundError('Document not found');
  }

  const newDocumentId = generateId();
  
  // Copy existing document settings and merge with new preferences
  documentStore.set(newDocumentId, {
    status: 'processing',
    format: preferences?.format || existingDoc.format,
  });

  // Process new document asynchronously
  processDocument(newDocumentId, preferences).catch(error => {
    documentStore.set(newDocumentId, {
      status: 'failed',
      format: existingDoc.format,
      message: error.message,
    });
  });

  return {
    documentId: newDocumentId,
    previousVersionId: documentId,
    status: 'processing',
    format: preferences?.format || existingDoc.format,
  };
}

export async function getDocumentStatus(documentId: string) {
  const doc = documentStore.get(documentId);
  if (!doc) {
    throw new NotFoundError('Document not found');
  }
  return doc;
}

async function processDocument(
  documentId: string,
  preferences: Partial<DocumentPreferences>,
  fileIds?: string[]
) {
  try {
    // TODO: Implement actual document processing logic with OpenAI
    // This is a placeholder that simulates processing
    await new Promise(resolve => setTimeout(resolve, 5000));

    // Update document status
    documentStore.set(documentId, {
      status: 'completed',
      url: `https://example.com/documents/${documentId}`,
      format: preferences.format || 'pdf',
    });
  } catch (error) {
    documentStore.set(documentId, {
      status: 'failed',
      format: preferences.format || 'pdf',
      message: error instanceof Error ? error.message : 'Processing failed',
    });
    throw error;
  }
}