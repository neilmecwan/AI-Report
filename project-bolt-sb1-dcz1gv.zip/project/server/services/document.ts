import OpenAI from 'openai';
import { config } from '../config/env.js';

const openai = new OpenAI({
  apiKey: config.OPENAI_API_KEY,
});

interface GenerateDocumentParams {
  files: Express.Multer.File[];
  audience: string;
  tone: string;
  format: string;
  prompt: string;
}

export async function generateDocument({
  files,
  audience,
  tone,
  format,
  prompt,
}: GenerateDocumentParams) {
  try {
    // Process files and extract content
    const fileContents = files.map(file => ({
      name: file.originalname,
      content: file.buffer.toString('utf-8'),
    }));

    // Create a prompt for the AI
    const systemPrompt = `You are an expert document creator. Generate a ${format} document for a ${audience} audience using a ${tone} tone. Consider the following files and additional instructions: ${prompt}`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: JSON.stringify(fileContents) }
      ],
    });

    return {
      content: completion.choices[0].message.content,
      format,
    };
  } catch (error) {
    console.error('Error in document generation:', error);
    throw new Error('Failed to generate document');
  }
}