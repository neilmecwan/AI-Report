import { FastifyError, FastifyReply, FastifyRequest } from 'fastify';
import { AppError } from '../utils/errors';

export function errorHandler(
  error: FastifyError,
  request: FastifyRequest,
  reply: FastifyReply
) {
  request.log.error(error);

  if (error instanceof AppError) {
    return reply.status(error.statusCode).send({
      success: false,
      error: error.message,
    });
  }

  // Handle validation errors from fastify
  if (error.validation) {
    return reply.status(400).send({
      success: false,
      error: error.message,
    });
  }

  // Handle unknown errors
  return reply.status(500).send({
    success: false,
    error: 'Internal server error',
  });
}