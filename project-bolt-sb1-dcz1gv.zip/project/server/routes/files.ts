import { FastifyPluginAsync } from 'fastify';
import { processUpload } from '../services/fileService';
import { BadRequestError } from '../utils/errors';

export const fileRouter: FastifyPluginAsync = async (fastify) => {
  fastify.post('/', async (request, reply) => {
    const files = await request.files();
    
    if (!files) {
      throw new BadRequestError('No files uploaded');
    }

    const processedFiles = await Promise.all(
      Array.from(files).map(file => processUpload(file))
    );

    return { files: processedFiles };
  });
};