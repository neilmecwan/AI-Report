import { FastifyPluginAsync } from 'fastify';
import { generateDocument, regenerateDocument, getDocumentStatus } from '../services/documentService';
import { validateGenerateRequest, validateRegenerateRequest } from '../utils/validators';

export const documentRouter: FastifyPluginAsync = async (fastify) => {
  fastify.post('/generate', async (request, reply) => {
    const payload = validateGenerateRequest(request.body);
    const result = await generateDocument(payload);
    return result;
  });

  fastify.post('/regenerate/:id', async (request, reply) => {
    const { id } = request.params as { id: string };
    const payload = validateRegenerateRequest(request.body);
    const result = await regenerateDocument(id, payload);
    return result;
  });

  fastify.get('/status/:id', async (request, reply) => {
    const { id } = request.params as { id: string };
    const status = await getDocumentStatus(id);
    return status;
  });
};