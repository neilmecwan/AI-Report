import { Router } from 'express';
import multer from 'multer';
import { generateDocument } from '../services/document.js';

const router = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

router.post('/generate', async (req, res) => {
  try {
    const { preferences, fileIds } = req.body;
    console.log('Generate request:', { preferences, fileIds });

    if (!preferences || !fileIds || !Array.isArray(fileIds)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid request. Missing preferences or fileIds'
      });
    }

    const document = await generateDocument({
      preferences,
      fileIds
    });

    res.json({ success: true, data: document });
  } catch (error) {
    console.error('Error generating document:', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to generate document'
    });
  }
});

export { router as documentRoutes };