import express from 'express';
import cors from 'cors';
import multer from 'multer';
import dotenv from 'dotenv';
import { OpenAI } from 'openai';
import { documentRoutes } from './routes/document.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Configure CORS with specific origin
app.use(cors({
  origin: 'https://guileless-heliotrope-b248e2.netlify.app',
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

app.use(express.json());

// Configure multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'healthy' });
});

// File upload endpoint
app.post('/api/upload', upload.array('files'), async (req, res) => {
  try {
    const files = req.files;
    if (!files || !Array.isArray(files)) {
      throw new Error('No files uploaded');
    }

    const processedFiles = files.map(file => ({
      id: Math.random().toString(36).substring(7),
      name: file.originalname,
      type: file.mimetype,
      size: file.size
    }));

    res.json({ 
      success: true, 
      files: processedFiles 
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ 
      success: false, 
      error: 'File upload failed' 
    });
  }
});

// Use document routes
app.use('/api/documents', documentRoutes);

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});