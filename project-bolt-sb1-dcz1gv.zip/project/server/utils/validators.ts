import { z } from 'zod';
import { ValidationError } from './errors';

const documentPreferencesSchema = z.object({
  audience: z.string(),
  tone: z.string(),
  format: z.enum(['pdf', 'ppt', 'docx']),
  prompt: z.string().optional(),
});

const generateRequestSchema = z.object({
  preferences: documentPreferencesSchema,
  fileIds: z.array(z.string()),
});

const regenerateRequestSchema = z.object({
  preferences: documentPreferencesSchema.partial().optional(),
});

export function validateGenerateRequest(data: unknown) {
  const result = generateRequestSchema.safeParse(data);
  if (!result.success) {
    throw new ValidationError(result.error.message);
  }
  return result.data;
}

export function validateRegenerateRequest(data: unknown) {
  const result = regenerateRequestSchema.safeParse(data);
  if (!result.success) {
    throw new ValidationError(result.error.message);
  }
  return result.data;
}