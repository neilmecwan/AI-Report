import React, { useState } from 'react';
import toast from 'react-hot-toast';
import { Loader2 } from 'lucide-react';

interface DocumentFormProps {
  files: File[];
  isGenerating: boolean;
  setIsGenerating: (value: boolean) => void;
}

const DocumentForm: React.FC<DocumentFormProps> = ({
  files,
  isGenerating,
  setIsGenerating,
}) => {
  const [audience, setAudience] = useState('');
  const [tone, setTone] = useState('');
  const [format, setFormat] = useState('');
  const [prompt, setPrompt] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (files.length === 0) {
      toast.error('Please upload at least one file');
      return;
    }

    try {
      setIsGenerating(true);
      const response = await fetch('https://report-ai-backend.onrender.com/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt,
          audience,
          tone,
          format,
        }),
      });

      if (!response.ok) {
        throw new Error('Generation failed');
      }

      const data = await response.json();
      if (data.success) {
        // Handle successful generation (e.g., download file)
        toast.success('Document generated successfully!');
      } else {
        throw new Error(data.error || 'Generation failed');
      }
    } catch (error) {
      console.error('Generation error:', error);
      toast.error('Failed to generate document. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-1">Target Audience</label>
        <select
          value={audience}
          onChange={(e) => setAudience(e.target.value)}
          required
          className="w-full bg-white/10 rounded-md border border-gray-600 px-3 py-2 text-white"
        >
          <option value="">Select audience</option>
          <option value="technical">Technical</option>
          <option value="business">Business</option>
          <option value="general">General</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Tone</label>
        <select
          value={tone}
          onChange={(e) => setTone(e.target.value)}
          required
          className="w-full bg-white/10 rounded-md border border-gray-600 px-3 py-2 text-white"
        >
          <option value="">Select tone</option>
          <option value="formal">Formal</option>
          <option value="casual">Casual</option>
          <option value="professional">Professional</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Output Format</label>
        <select
          value={format}
          onChange={(e) => setFormat(e.target.value)}
          required
          className="w-full bg-white/10 rounded-md border border-gray-600 px-3 py-2 text-white"
        >
          <option value="">Select format</option>
          <option value="pdf">PDF</option>
          <option value="ppt">PowerPoint</option>
          <option value="docx">Word Document</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Additional Instructions</label>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          required
          className="w-full bg-white/10 rounded-md border border-gray-600 px-3 py-2 text-white min-h-[100px]"
          placeholder="Enter any specific requirements or guidance..."
        />
      </div>

      <button
        type="submit"
        disabled={isGenerating || files.length === 0}
        className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white py-2 px-4 rounded-md font-medium
          hover:from-blue-600 hover:to-purple-600 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isGenerating ? (
          <span className="flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin" />
            Generating...
          </span>
        ) : (
          'Generate Document'
        )}
      </button>
    </form>
  );
};

export default DocumentForm;