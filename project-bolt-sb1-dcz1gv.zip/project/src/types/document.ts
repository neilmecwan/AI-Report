export interface DocumentPreferences {
  audience: string;
  tone: string;
  format: DocumentFormat;
  prompt: string;
}

export type DocumentFormat = 'pdf' | 'ppt' | 'docx';

export interface GeneratedDocument {
  url: string;
  format: DocumentFormat;
  timestamp: string;
}

export interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: number;
}

export type GenerationStatus = 'idle' | 'generating' | 'success' | 'error';