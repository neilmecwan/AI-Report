export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

export interface UploadResponse {
  files: Array<{
    id: string;
    url: string;
    name: string;
    type: string;
    size: number;
  }>;
}

export interface GenerateResponse {
  documentId: string;
  url: string;
  format: string;
  status: 'completed' | 'processing' | 'failed';
  message?: string;
}

export interface RegenerateResponse extends GenerateResponse {
  previousVersionId: string;
}