import { useState } from 'react';
import toast from 'react-hot-toast';
import { documentService } from '../services/documentService';
import type { UploadedFile, GenerationStatus } from '../types/document';

export function useDocumentGeneration() {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [status, setStatus] = useState<GenerationStatus>('idle');
  const [currentDocumentId, setCurrentDocumentId] = useState<string | null>(null);

  const handleFileUpload = async (files: File[]) => {
    try {
      setStatus('uploading');
      const response = await documentService.uploadFiles(files);
      
      if (!response.success || !response.data) {
        throw new Error(response.error || 'Upload failed');
      }

      setUploadedFiles(prev => [...prev, ...response.data.files]);
      toast.success(`${files.length} file${files.length === 1 ? '' : 's'} uploaded successfully`);
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload files');
    } finally {
      setStatus('idle');
    }
  };

  const generateDocument = async (formData: FormData) => {
    if (uploadedFiles.length === 0) {
      toast.error('Please upload at least one file');
      return;
    }

    try {
      setStatus('generating');
      
      const preferences = {
        audience: formData.get('audience') as string,
        tone: formData.get('tone') as string,
        format: formData.get('format') as string,
        prompt: formData.get('prompt') as string,
      };

      const fileIds = uploadedFiles.map(file => file.id);
      const response = await documentService.generateDocument(preferences, fileIds);

      if (!response.success || !response.data) {
        throw new Error(response.error || 'Generation failed');
      }

      setCurrentDocumentId(response.data.documentId);
      toast.success('Document generation started');

      // Poll for status
      const checkStatus = async () => {
        const statusResponse = await documentService.checkStatus(response.data.documentId);
        
        if (statusResponse.success && statusResponse.data) {
          if (statusResponse.data.status === 'completed') {
            setStatus('success');
            toast.success('Document generated successfully');
            window.open(statusResponse.data.url, '_blank');
          } else if (statusResponse.data.status === 'failed') {
            throw new Error(statusResponse.data.message || 'Generation failed');
          } else {
            setTimeout(checkStatus, 2000);
          }
        }
      };

      checkStatus();
    } catch (error) {
      console.error('Generation error:', error);
      setStatus('error');
      toast.error('Failed to generate document');
    }
  };

  const regenerateDocument = async () => {
    if (!currentDocumentId) {
      toast.error('No document to regenerate');
      return;
    }

    try {
      setStatus('generating');
      const response = await documentService.regenerateDocument(currentDocumentId);

      if (!response.success || !response.data) {
        throw new Error(response.error || 'Regeneration failed');
      }

      setCurrentDocumentId(response.data.documentId);
      toast.success('Document regeneration started');

      // Poll for status
      const checkStatus = async () => {
        const statusResponse = await documentService.checkStatus(response.data.documentId);
        
        if (statusResponse.success && statusResponse.data) {
          if (statusResponse.data.status === 'completed') {
            setStatus('success');
            toast.success('Document regenerated successfully');
            window.open(statusResponse.data.url, '_blank');
          } else if (statusResponse.data.status === 'failed') {
            throw new Error(statusResponse.data.message || 'Regeneration failed');
          } else {
            setTimeout(checkStatus, 2000);
          }
        }
      };

      checkStatus();
    } catch (error) {
      console.error('Regeneration error:', error);
      setStatus('error');
      toast.error('Failed to regenerate document');
    }
  };

  return {
    status,
    uploadedFiles,
    handleFileUpload,
    generateDocument,
    regenerateDocument,
  };
}