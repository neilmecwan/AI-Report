import React, { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { FileText, Wand2, Upload, CheckCircle2, XCircle } from 'lucide-react';
import FileUpload from './components/FileUpload';
import DocumentForm from './components/DocumentForm';

function App() {
  const [files, setFiles] = useState<File[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [backendStatus, setBackendStatus] = useState<'checking' | 'online' | 'offline'>('checking');

  useEffect(() => {
    const checkBackendStatus = async () => {
      try {
        const response = await fetch('https://report-ai-backend.onrender.com/health');
        if (response.ok) {
          setBackendStatus('online');
        } else {
          setBackendStatus('offline');
        }
      } catch (error) {
        console.error('Backend connection error:', error);
        setBackendStatus('offline');
      }
    };

    checkBackendStatus();
  }, []);

  return (
    <div className="min-h-screen bg-[#020817] text-white">
      <Toaster position="top-right" />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center mb-4">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-[#67e8f9] via-[#818cf8] to-[#c084fc] text-transparent bg-clip-text">
            REPORT AI
          </h1>
        </div>

        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5">
            <span>Backend Status:</span>
            {backendStatus === 'checking' ? (
              <span className="flex items-center gap-1">
                <span className="animate-pulse">Checking connection...</span>
              </span>
            ) : backendStatus === 'online' ? (
              <span className="flex items-center gap-1 text-green-400">
                <CheckCircle2 className="w-4 h-4" />
                Connected
              </span>
            ) : (
              <span className="flex items-center gap-1 text-red-400">
                <XCircle className="w-4 h-4" />
                Offline
              </span>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <FileUpload onFilesSelected={setFiles} />
            <div className="bg-white/5 rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Upload className="w-5 h-5" />
                Uploaded Files
              </h2>
              <ul className="space-y-2">
                {files.map((file, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    <span>{file.name}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-white/5 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Wand2 className="w-5 h-5" />
              Generate Document
            </h2>
            <DocumentForm 
              files={files}
              isGenerating={isGenerating}
              setIsGenerating={setIsGenerating}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;