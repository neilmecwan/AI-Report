import api from './api';

export const documentService = {
  async uploadFiles(files: File[]) {
    try {
      const formData = new FormData();
      files.forEach((file) => {
        formData.append('files', file);
      });

      const response = await api.post('/api/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return { success: true, data: response.data };
    } catch (error) {
      console.error('Upload error:', error);
      return { success: false, error: 'File upload failed' };
    }
  },

  async generateDocument(preferences: any, fileIds: string[]) {
    try {
      const response = await api.post('/api/generate', {
        preferences,
        fileIds,
      });
      return { success: true, data: response.data };
    } catch (error) {
      console.error('Generation error:', error);
      return { success: false, error: 'Document generation failed' };
    }
  },
};